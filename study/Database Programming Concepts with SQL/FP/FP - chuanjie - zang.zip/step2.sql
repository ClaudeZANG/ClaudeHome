CREATE DATABASE HS_Employees;
USE HS_Employees;
