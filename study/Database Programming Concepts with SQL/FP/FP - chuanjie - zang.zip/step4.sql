INSERT INTO Employees (EmployeeID, LoginID, Password, GroupType, FirstName, LastName, SocialInsuranceNumber, PhoneOffice) VALUES
('MJ1001', 'mjohnson', '12ofmarch', 'Associate', 'Mary', 'Johnson', '234 543 679', 'x1014'),
('NK1001', 'nketchm', 'fastcars', 'Manager', 'Noel', 'Ketchum', '477 346 230', 'x1300'),
('TT1001', 'ttipple', 'qwerty', 'Owner', 'Tim', 'Tipple', '349 193 409', 'x1000'),
('BL1002', 'blarson', 'zooanimals', 'Associate', 'Ben', 'Larson', '488 420 350', 'x1010'),
('LS1001', 'lsiskins', 'rainbow', 'Manager', 'Laura', 'Siskins', '472 450 269', 'x2213'),
('FS1002', 'fsanders', 'lopsidez', 'Associate', 'Fred', 'Sanders', '301 394 278', 'x1011'),
('LS1002', 'lsamson', 'letmein', 'Associate', 'Lisa', 'Samson', '487 389 248', 'x1012');
