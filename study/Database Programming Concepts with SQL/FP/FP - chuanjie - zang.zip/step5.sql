SELECT * FROM Employees;
