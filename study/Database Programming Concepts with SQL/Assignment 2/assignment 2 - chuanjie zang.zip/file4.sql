CREATE DATABASE UrbanRealEstate;

