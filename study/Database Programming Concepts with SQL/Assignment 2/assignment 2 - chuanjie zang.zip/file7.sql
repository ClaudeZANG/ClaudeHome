SELECT * FROM Clients;

SELECT * FROM Clients;

SELECT * FROM Properties;

SELECT * FROM Transactions;

