// Common JavaScript code for the site
document.addEventListener('DOMContentLoaded', function() {
    // Code that runs on every page
    console.log('Page fully loaded and parsed');
    // Initialize other functionalities if needed
});
