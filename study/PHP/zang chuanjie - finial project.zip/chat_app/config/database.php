<?php
// database.php
return [
    'host' => 'localhost',
    'username' => 'yourUsername',
    'password' => 'yourPassword',
    'database' => 'chat_app',
];
