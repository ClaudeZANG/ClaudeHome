// JavaScript for assignment2.html
// Add any interactive features here
